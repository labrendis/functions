
enum Sandwitch {
    case bread
    case meat
    case condiments
    case veggies
    case cheese
    
}
enum bread: CaseIterable {
    case wheat, italian , white, multigrain
}
let number1 = bread.allCases.count
print("There are \(number1) breads to choose from")

enum meat: CaseIterable {
    case ham, buffaloChicken, chicken, turkey
}
let number2 = meat.allCases.count
print("There are \(number2) meats to choose from")

enum condiments: CaseIterable {
    case ketchup, mustard, mayonnaise, lime, avocado
}
let number3 = condiments.allCases.count
print("There are \(number3) condiments to choose from")

enum veggies: CaseIterable {
    case spinach, lettuce, tomatoes, cucumbers
}
let number4 = veggies.allCases.count
print("There are \(number4) veggies to choose from")

enum cheese: CaseIterable {
    case american, cheedar
}
let number5 = cheese.allCases.count
print("There are \(number5) cheese to choose from")
